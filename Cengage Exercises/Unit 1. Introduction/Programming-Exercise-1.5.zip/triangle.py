# Edit the code below (from Projeb
base = float(input("Enter the base: "))
height = float(input("Enter the height: "))
area = 0.5 * base * height
print("The area is", area, "square units.")
